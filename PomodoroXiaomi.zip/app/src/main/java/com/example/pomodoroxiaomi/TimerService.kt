package com.example.pomodoroxiaomi

import android.app.*
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.Locale

class TimerService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private var workMs = 20 * 60_000L
    private var breakMs = 3 * 60_000L
    private var isWork = true
    private var running = false
    private var tone: ToneGenerator? = null

    companion object {
        const val CHANNEL_ID = "pomodoro_timer"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START = "start"
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.hasExtra("workMinutes") == true) {
            workMs = intent.getLongExtra("workMinutes", 20) * 60_000L
            breakMs = intent.getLongExtra("breakMinutes", 3) * 60_000L
            isWork = true
            endAt = System.currentTimeMillis() + workMs
            running = true
        }

        startForeground(NOTIFICATION_ID, notification("کار", workMs))
        handler.removeCallbacksAndMessages(null)
        handler.post(tick)
        return START_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return

            val remaining = endAt - System.currentTimeMillis()
            if (remaining <= 0) {
                tone?.startTone(ToneGenerator.TONE_PROP_BEEP2, 800)
                isWork = !isWork
                endAt = System.currentTimeMillis() + if (isWork) workMs else breakMs
            }

            val current = endAt - System.currentTimeMillis()
            startForeground(
                NOTIFICATION_ID,
                notification(if (isWork) "کار" else "استراحت", current)
            )
            handler.postDelayed(this, 1000)
        }
    }

    private fun notification(phase: String, remaining: Long): Notification {
        val mins = (remaining.coerceAtLeast(0) / 60_000)
        val secs = ((remaining.coerceAtLeast(0) % 60_000) / 1000)
        val text = String.format(Locale.US, "%02d:%02d باقی مانده", mins, secs)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Pomodoro — $phase")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .build()
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Pomodoro Timer",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "اعلان تایمر پومودورو"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        tone?.release()
        tone = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}

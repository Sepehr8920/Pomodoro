package com.example.pomodoroxiaomi

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var workInput: EditText
    private lateinit var breakInput: EditText
    private lateinit var status: TextView

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 40, 36, 24)
        }

        TextView(this).apply {
            text = "Pomodoro"
            textSize = 30f
        }.also { root.addView(it) }

        TextView(this).apply {
            text = "زمان کار (دقیقه)"
            textSize = 18f
        }.also { root.addView(it) }

        workInput = EditText(this).apply {
            inputType = 2
            setText("20")
        }
        root.addView(workInput)

        TextView(this).apply {
            text = "زمان استراحت (دقیقه)"
            textSize = 18f
        }.also { root.addView(it) }

        breakInput = EditText(this).apply {
            inputType = 2
            setText("3")
        }
        root.addView(breakInput)

        Button(this).apply {
            text = "شروع"
            setOnClickListener { startTimer() }
        }.also { root.addView(it) }

        Button(this).apply {
            text = "توقف"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TimerService::class.java))
                status.text = "متوقف شد"
            }
        }.also { root.addView(it) }

        status = TextView(this).apply {
            text = "آماده"
            textSize = 20f
            setPadding(0, 30, 0, 0)
        }
        root.addView(status)

        TextView(this).apply {
            text = "نکته: برای جلوگیری از توقف تایمر توسط HyperOS، اجرای خودکار و Battery Saver را برای برنامه بررسی کنید."
            textSize = 15f
            setPadding(0, 30, 0, 0)
        }.also { root.addView(it) }

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun startTimer() {
        val work = workInput.text.toString().toLongOrNull() ?: 20
        val rest = breakInput.text.toString().toLongOrNull() ?: 3

        if (work <= 0 || rest <= 0) {
            Toast.makeText(this, "زمان‌ها باید بیشتر از صفر باشند", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, TimerService::class.java).apply {
            putExtra("workMinutes", work)
            putExtra("breakMinutes", rest)
        }
        ContextCompat.startForegroundService(this, intent)
        status.text = "تایمر اجرا شد"
    }
}
